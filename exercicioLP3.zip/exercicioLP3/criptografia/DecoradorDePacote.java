public abstract class DecoradorDePacote implements IPacote {

    public abstract void criptografar();
    public abstract void prepararDados(String dados);

}

