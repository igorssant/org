public abstract class GUIAbstractFactory {
    
    public abstract AbstractPacote criarPacote ();
    public abstract AbstractRemetente criarRemetente ();
    
}