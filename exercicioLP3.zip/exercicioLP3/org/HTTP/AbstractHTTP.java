public abstract class AbstractHTTP {
    
    public abstract void remetenteHTTP ();
    public abstract void pacoteHTTP ();
    
}