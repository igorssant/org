public class Autenticar implements IAutenticar{

    public void autenticar()
    {
        System.out.print("Autenticar");
    }
}
