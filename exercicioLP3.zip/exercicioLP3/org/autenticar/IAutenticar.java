public interface IAutenticar {

    public void autenticar();
}
