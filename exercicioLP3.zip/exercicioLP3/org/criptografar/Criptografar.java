public class Criptografar implements ICriptografar{

    public void criptografar()
    {
        System.out.print("Criptografia");
    }
}
