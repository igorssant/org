public interface ICriptografar {

    public void criptografar();
}
