public class PacoteCOAP implements IPacote {

    private String dados;

    public void prepararDados(String dados)
    {
        System.out.println("Preparando dados: "+dados+" com COAP");
        setDados(dados);

    }
    public  void criptografar()
    {
        System.out.println("Criptografia Padrao");
    }

    public String getDados() {
        return dados;
    }

    public void setDados(String dados) {
        this.dados = dados;
    }
}
