public class RemetenteCOAP implements IRemetente
{

    @Override
    public void connect(String enderecoDeDestino)
    {
        System.out.println("Conectando ao endereço:\t" + enderecoDeDestino+".COAP");
    }

    @Override
    public void autenticar()
    {
        System.out.println("Autenticando com COAP");
    }

    @Override
    public void send(IPacote dados)
    {
        System.out.println("Enviando dados: "+dados+" com COAP");
    }

    @Override
    public void close()
    {
        System.out.println("Encerrando COAP"); 
    }
 
}
