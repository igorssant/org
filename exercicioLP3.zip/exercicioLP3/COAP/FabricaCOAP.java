
public class FabricaCOAP implements IFabrica {

    @Override
    public IPacote createPacote()
    {
        return new PacoteCOAP();
    }

    @Override
    public IRemetente createRemetente()
    {
        return new RemetenteCOAP();
    }
}
