public class teste
{

    public static void main(String[] args)
    {
        /*Teste das fábricas*/

        //COAP
        System.out.println("Teste com COAP\n");
        IFabrica fabricaQualquer = new FabricaCOAP();
        IPacote pacoteQualquer = fabricaQualquer.createPacote();
        IRemetente remetenteQualquer = fabricaQualquer.createRemetente();

        pacoteQualquer.prepararDados("senhas de banco roubadas");
        pacoteQualquer.criptografar();

        remetenteQualquer.connect("wwww.vendesenhas.com.br");
        remetenteQualquer.autenticar();
        remetenteQualquer.send(pacoteQualquer);
        remetenteQualquer.close();

        //HTTP
        System.out.println("\n\n\nTeste com HTTP\n");
        fabricaQualquer = new FabricaHTTP();
        pacoteQualquer = fabricaQualquer.createPacote();
        remetenteQualquer = fabricaQualquer.createRemetente();

        pacoteQualquer.prepararDados("informações telefônicas roubadas");
        pacoteQualquer.criptografar();

        remetenteQualquer.connect("wwww.darkestweb.com.br");
        remetenteQualquer.autenticar();
        remetenteQualquer.send(pacoteQualquer);
        remetenteQualquer.close();


        /*Teste com o Decorador*/

        
    }
    
}
