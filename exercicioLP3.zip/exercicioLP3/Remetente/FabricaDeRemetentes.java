public interface FabricaDeRemetentes
{
    public IRemetente criarRemetente();
    public IPacote criarPacote();
    
}
