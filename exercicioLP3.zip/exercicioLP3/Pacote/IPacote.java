public interface IPacote
{
    public void prepararDados(String dados);
    public void criptografar();
}
