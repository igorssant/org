public interface IFabrica {

    public  IPacote createPacote();
    public IRemetente createRemetente();

   /* public DecoradorDePacoteCriptografiaDES criarCriptografiaDES();
    public DecoradorDePacoteCriptografiaRSA criarCriptografiaRSA();

    public DecoradorDeAutenticacaoSenha criarAutenticacaoSenha();
    public DecoradorDeAutenticacaoToken criarAutenticacaoToken();*/
}
