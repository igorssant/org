public abstract class DecoradorDeRemetente implements IRemetente
{

    public abstract void autenticar();
}
