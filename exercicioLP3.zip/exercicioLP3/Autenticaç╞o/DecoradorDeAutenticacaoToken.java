public class DecoradorDeAutenticacaoToken extends DecoradorDeRemetente {

    private IRemetente remetente;

    public DecoradorDeAutenticacaoToken(IRemetente remetente)
    {
        this.remetente = remetente;
    }

    @Override
    public void connect(String enderecoDeDestino)
    {
        this.remetente.connect(enderecoDeDestino);
        
    }

    @Override
    public void send(IPacote dados) {
        this.remetente.send(dados);
        
    }

    @Override
    public void close()
    {
        this.remetente.close();
    }

    @Override
    public void autenticar()
    {
        System.out.println("Autenticando com token");
        this.remetente.autenticar();
    }
    
}
