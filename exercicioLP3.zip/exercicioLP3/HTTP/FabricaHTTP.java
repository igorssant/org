public class FabricaHTTP implements IFabrica{

    @Override
    public IPacote createPacote()
    {
        return new PacoteHTTP ();
    }

    @Override
    public IRemetente createRemetente ()
    {
        return new RemetenteHTTP();
    }

 
    
}