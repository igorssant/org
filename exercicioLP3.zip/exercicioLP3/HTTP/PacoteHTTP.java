public class PacoteHTTP implements IPacote {

    private String dados;

    public void prepararDados(String dados)
    {
        System.out.println("Preparando: "+dados+" com HTTP");
        setDados(dados);
    }
    public  void criptografar()
    {
        System.out.println("Criptografia: Padrao");
    }

    public String getDados() {
        return dados;
    }

    public void setDados(String dados) {
        this.dados = dados;
    }
}


